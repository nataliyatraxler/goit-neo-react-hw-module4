import { Oval } from 'react-loader-spinner';

const Loader = () => (
  <div>
    <Oval color="blue" height={50} width={50} />
  </div>
);

export default Loader;
